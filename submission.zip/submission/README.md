# About

A project to model the electricity usage of buildings. Used to predict past or future energy usage of a building at any given hour or day.

# Github

https://github.com/JackLockhart04/building_energy_predictor

# Run demo

Run main.py for backend with venv
Open frontend/index.html with a browser

### Pip installs

Use requirements.txt with a venv